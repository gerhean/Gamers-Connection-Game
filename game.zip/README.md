# Itch.io Link

https://gerhean.itch.io/gamers-connection

# Attributions

## Music:

- Sound Novel: Visual Novel Music Pack - Rest (https://rest--vgmusic.weebly.com/)

- Big music pack for visual novel (or something else) - TERNOX (https://ternox.itch.io/vn-music)

## Voice:

- Free Voice Clips Pack (Bright Female) - Cici Fyre (https://cicifyre.itch.io/free-voice-clips-pack-bright-female)

- Free Voice Clips Pack (Mature Female) - Cici Fyre (https://cicifyre.itch.io/free-voice-clips-pack-mature-female)

- Super Dialogue Audio Pack - Dillon Becker (https://dillonbecker.itch.io/sdap)

## Sound:

- 320655__rhodesmas__level-up-01.mp3 - shinephoenixstormcrow (https://freesound.org/people/shinephoenixstormcrow/sounds/337049/)

- level up.wav - MakoFox (https://freesound.org/people/MakoFox/sounds/126422/)

- cat2.wav - NoiseCollector (https://freesound.org/people/NoiseCollector/sounds/4914/)

- bells.ringing_church_close.mp3 - dobroide (https://freesound.org/people/dobroide/sounds/4243/)

-  phone vibrate.wav - lartti (https://freesound.org/people/lartti/sounds/529979/)

## Background:

- Uncle Mugen's Free OELVN / Visual Novel Resources - mugenjohncel (https://lemmasoft.renai.us/forums/viewtopic.php?f=52&t=17302)

- Free Visual Novel Backgrounds (Starter Pack) -  potat0master(https://potat0master.itch.io/free-visual-novel-backgrounds-starter-pack)

- Noraneko_Background_Pack - Noraneko Games (Noranekokgames.itch.io)

- Dating sim ui pack - LoudEyes (https://loudeyes.itch.io/dating-sim-ui-pack)

- Jinego Elementary School nurses office back - Douglas P. Perkins (https://commons.wikimedia.org/wiki/File:Jinego_Elementary_School_nurses_office_back.jpg)

- Gallery mockup psd created by rawpixel.com - www.freepik.com (https://www.freepik.com/psd/gallery-mockup)

- Photo by ASIA CULTURECENTER (https://unsplash.com/@asiaculturecenter?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on Unsplash (https://unsplash.com/photos/0tUtCmkEzdU)


## Sprite:

- Female Character Sprite for Visual Novel - sutemo (https://sutemo.itch.io/female-character)

- Male Character Sprite for Visual Novel - sutemo(https://sutemo.itch.io/male-character-sprite-for-visual-novel)
